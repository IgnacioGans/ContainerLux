    <?php
    $args = array(
        'post_type' => 'carousel_item',
        'posts_per_page' => -1,
    );

    $carousel_items = new WP_Query($args);

    if ($carousel_items->have_posts()) :
    ?>
        <div id="carouselExample" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <?php
                $count = 0;
                while ($carousel_items->have_posts()) :
                    $carousel_items->the_post();
                ?>
                    <div class="carousel-item <?php echo ($count === 0) ? 'active' : ''; ?>">
                        <?php the_post_thumbnail('large', array('class' => 'd-block w-100')); ?>
                        <div class="carousel-caption d-none d-md-block">
                            <h5><?php the_title(); ?></h5>
                            <p><?php the_excerpt(); ?></p>
                        </div>
                    </div>
                <?php
                    $count++;
                endwhile;
                ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    <?php
    endif;
    wp_reset_postdata();
    ?>


    <?php wp_footer(); ?>
    </body>

    </html>